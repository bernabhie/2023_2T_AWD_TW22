function change(color) {
    var box = document.querySelector(".box-cont");
    box.style.borderColor = color;
    box.style.marginTop = "0px"; // Slide down by setting margin-top to 0
}